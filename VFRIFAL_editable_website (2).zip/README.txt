VFRIFAL WEBSITE PROTOTYPE

Open index.html in a browser. Upload the full folder to a static hosting provider to publish.

Pages: Home, Farming, Safe Water, Enterprise, Field Journal, Contact.
Logo: extracted from the supplied constitution cover.

Before launch:
1. Confirm organisation names, registration numbers and legal relationship of UK guarantee company, Sierra Leone chapter and proposed shares company.
2. Add verified email, telephone, privacy notice, safeguarding/media-consent policy and official social media links.
3. Add a verified GoFundMe link and project budget before taking donations. Do not use the disabled fundraising button as a payment link.
4. Gallery additions are LOCAL ONLY to the browser. For public photo/video uploads and editorial moderation, integrate a CMS and media hosting service.
5. Obtain consent from anyone identifiable in field media, especially children.
6. Replace illustrative emojis with licensed photographs when available.

Source material: VFRIFAL Salone Constitution (2020); UK VFRIFA Memorandum (2020); Sierra Leone registration certificate supplied by user.
