VFRIFAL WEBSITE — PUBLISHING AND EDITING

1. Create a FREE GitHub account and a new repository (e.g. vfrifal-website). Upload ALL files and folders from this ZIP to the repository root, including .pages.yml (hidden file). Do not upload the ZIP as a single file.
2. Visit https://pagescms.org and sign in with GitHub. Select your vfrifal-website repository. Pages CMS reads .pages.yml and gives you visual forms for text, fonts, links, and photo/video updates. Changes are saved to GitHub.
3. Visit https://app.netlify.com/drop and drag in the unzipped site folder for a first live URL (ending .netlify.app). For automatic publishing of later Pages CMS edits, in Netlify select Add new project > Import an existing project > GitHub > vfrifal-website. Publish directory: / (repository root). No build command required.
4. Pages CMS: edit Website text, fonts and links; edit Farming photo and video journal. Upload new photos under assets/uploads and select their image path. For videos, paste a public YouTube link.
5. Add only a VERIFIED GoFundMe URL and half-marathon link. Fundraising buttons appear when URLs are supplied. Donations are processed by the external fundraiser, not this site.
6. The original logo is included. Uploaded farming photographs are included. The exact dates and locations of the images are unverified and captions say so.
7. No live site URL can be issued until you deploy under your own Netlify/GitHub account. Do not publish personal statutory declarations or internal minutes. Review permissions for identifiable people in any new photos.
8. Important: UK VFRIFA is documented as limited by guarantee. Do not advertise the proposed shares business as registered until verified. Verify charity registration before claiming registered charity status.
